import streamlit as st
import pandas as pd
import plotly.express as px
import hashlib
import pymysql
import os
from datetime import datetime

# --- Database Connection ---
def get_db_connection():
    return pymysql.connect(
        host=os.getenv("DB_HOST", "cloudprojectdb.cg3yo8ao4rxa.us-east-1.rds.amazonaws.com"),
        user=os.getenv("DB_USER", "admin"),
        password=os.getenv("DB_PASS", "Admin123"),
        database=os.getenv("DB_NAME", "cld_prj_db"),
        port=int(os.getenv("DB_PORT", 3306)),
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=True
    )

# --- Database Initialization ---
def init_db():
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # Users Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS Users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(255) UNIQUE NOT NULL,
                    password_hash VARCHAR(255) NOT NULL
                )
            """)
            # Accounts Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS Accounts (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT,
                    name VARCHAR(255),
                    balance FLOAT,
                    FOREIGN KEY (user_id) REFERENCES Users(id)
                )
            """)
            # Categories Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS Categories (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT,
                    name VARCHAR(255),
                    type VARCHAR(50),
                    FOREIGN KEY (user_id) REFERENCES Users(id)
                )
            """)
            # Transactions Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS Transactions (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT,
                    date DATE,
                    amount FLOAT,
                    category VARCHAR(255),
                    account_id INT,
                    description TEXT,
                    FOREIGN KEY (user_id) REFERENCES Users(id),
                    FOREIGN KEY (account_id) REFERENCES Accounts(id)
                )
            """)
    finally:
        conn.close()

# --- Authentication ---
def make_hashes(password):
    return hashlib.sha256(str.encode(password)).hexdigest()

def check_hashes(password, hashed_text):
    if make_hashes(password) == hashed_text:
        return True
    return False

def register_user(username, password):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # Check if user exists
            cursor.execute("SELECT * FROM Users WHERE username = %s", (username,))
            if cursor.fetchone():
                return False, "Username already exists."
            
            # Create User
            password_hash = make_hashes(password)
            cursor.execute("INSERT INTO Users (username, password_hash) VALUES (%s, %s)", (username, password_hash))
            user_id = cursor.lastrowid
            
            # Create Default Accounts
            default_accounts = [("Cash", 0.0), ("Bank", 0.0)]
            for name, balance in default_accounts:
                cursor.execute("INSERT INTO Accounts (user_id, name, balance) VALUES (%s, %s, %s)", (user_id, name, balance))
            
            # Create Default Categories
            default_categories = [("Food", "Expense"), ("Salary", "Income"), ("Transport", "Expense"), ("Entertainment", "Expense")]
            for name, cat_type in default_categories:
                cursor.execute("INSERT INTO Categories (user_id, name, type) VALUES (%s, %s, %s)", (user_id, name, cat_type))
                
            return True, "User registered successfully!"
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()

def login_user(username, password):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM Users WHERE username = %s", (username,))
            user = cursor.fetchone()
            if user and check_hashes(password, user['password_hash']):
                return user
            return None
    finally:
        conn.close()

# --- Data Logic ---
def get_user_data(user_id):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # Fetch Transactions
            cursor.execute("SELECT * FROM Transactions WHERE user_id = %s ORDER BY date DESC", (user_id,))
            transactions = cursor.fetchall()
            
            # Fetch Accounts
            cursor.execute("SELECT * FROM Accounts WHERE user_id = %s", (user_id,))
            accounts = cursor.fetchall()
            
            # Fetch Categories
            cursor.execute("SELECT * FROM Categories WHERE user_id = %s", (user_id,))
            categories = cursor.fetchall()
            
            return pd.DataFrame(transactions), accounts, categories
    finally:
        conn.close()

def add_transaction(user_id, date, amount, category, account_id, description, type_):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # Insert Transaction
            cursor.execute("""
                INSERT INTO Transactions (user_id, date, amount, category, account_id, description)
                VALUES (%s, %s, %s, %s, %s, %s)
            """, (user_id, date, amount, category, account_id, description))
            
            # Update Account Balance
            if type_ == 'Expense':
                cursor.execute("UPDATE Accounts SET balance = balance - %s WHERE id = %s AND user_id = %s", (amount, account_id, user_id))
            else:
                cursor.execute("UPDATE Accounts SET balance = balance + %s WHERE id = %s AND user_id = %s", (amount, account_id, user_id))
            
            return True
    except Exception as e:
        st.error(f"Error adding transaction: {e}")
        return False
    finally:
        conn.close()

def add_account(user_id, name, balance=0.0):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("INSERT INTO Accounts (user_id, name, balance) VALUES (%s, %s, %s)", (user_id, name, balance))
            return True
    except Exception as e:
        st.error(f"Error adding account: {e}")
        return False
    finally:
        conn.close()



def delete_account(user_id, account_id):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # Delete transactions associated with this account first
            cursor.execute("DELETE FROM Transactions WHERE account_id = %s AND user_id = %s", (account_id, user_id))
            # Delete the account
            cursor.execute("DELETE FROM Accounts WHERE id = %s AND user_id = %s", (account_id, user_id))
            return True
    except Exception as e:
        st.error(f"Error deleting account: {e}")
        return False
    finally:
        conn.close()

def get_all_users():
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT u.id, u.username, SUM(a.balance) as total_balance 
                FROM Users u 
                LEFT JOIN Accounts a ON u.id = a.user_id 
                GROUP BY u.id
            """)
            return cursor.fetchall()
    finally:
        conn.close()

# --- Main App ---
def main():
    st.set_page_config(page_title="Personal Finance App", layout="wide")
    
    # Initialize DB (safe to run multiple times)
    init_db()
    
    if 'logged_in' not in st.session_state:
        st.session_state['logged_in'] = False
        st.session_state['user'] = None

    # --- Sidebar ---
    with st.sidebar:
        if st.session_state['logged_in']:
            st.title(f"Welcome, {st.session_state['user']['username']}")
            if st.button("Logout"):
                st.session_state['logged_in'] = False
                st.session_state['user'] = None
                st.rerun()
        else:
            st.title("Authentication")
            choice = st.radio("Login/Register", ["Login", "Register"])
            
            if choice == "Login":
                username = st.text_input("Username")
                password = st.text_input("Password", type='password')
                if st.button("Login"):
                    user = login_user(username, password)
                    if user:
                        st.session_state['logged_in'] = True
                        st.session_state['user'] = user
                        st.success("Logged in!")
                        st.rerun()
                    else:
                        st.error("Invalid credentials")
            
            else: # Register
                new_user = st.text_input("New Username")
                new_password = st.text_input("New Password", type='password')
                if st.button("Register"):
                    success, msg = register_user(new_user, new_password)
                    if success:
                        st.success(msg)
                    else:
                        st.error(msg)

        if st.session_state['logged_in']:
            # --- Admin Dashboard ---
            if st.session_state['user']['username'] == 'admin':
                with st.expander("Admin Dashboard", expanded=True):
                    st.subheader("All Users")
                    all_users = get_all_users()
                    if all_users:
                        st.dataframe(pd.DataFrame(all_users))
                    else:
                        st.info("No users found.")

            with st.expander("Manage Accounts"):
                # Add Account Form
                with st.form("add_account_form"):
                    new_acc_name = st.text_input("Account Name")
                    # Default balance is 0 as per requirements
                    submitted_acc = st.form_submit_button("Create Account")
                    if submitted_acc:
                        if new_acc_name:
                            if add_account(st.session_state['user']['id'], new_acc_name):
                                st.success(f"Account '{new_acc_name}' created!")
                                st.rerun()
                        else:
                            st.error("Please enter an account name.")
                
                # Delete Account Section
                st.markdown("---")
                st.subheader("Your Accounts")
                # Re-fetch accounts to ensure list is up to date if needed, 
                # but we can rely on the main fetch at start of loop if we rerun.
                # We need to access accounts here, but they are fetched below. 
                # Let's fetch them here or move this section down. 
                # Moving logic: The main page logic is below. Let's fetch accounts here for the sidebar.
                # Or better, just use the ones we will fetch. 
                # Since sidebar renders first, we might need to fetch here if we want to show them.
                # But `get_user_data` is called in the main block. 
                # Let's move `get_user_data` up or call it here.
                
                user_id = st.session_state['user']['id']
                _, sidebar_accounts, _ = get_user_data(user_id) # Re-using get_user_data but ignoring DF and cats
                
                for acc in sidebar_accounts:
                    col_acc_name, col_acc_del = st.columns([3, 1])
                    col_acc_name.write(f"{acc['name']} (AED {acc['balance']:,.2f})")
                    
                    if acc['name'] not in ["Cash", "Bank"]:
                        if col_acc_del.button("Delete", key=f"del_{acc['id']}"):
                            if delete_account(user_id, acc['id']):
                                st.success(f"Deleted {acc['name']}")
                                st.rerun()
                    else:
                        col_acc_del.write("🔒") # Lock icon for default accounts

    # --- Main Page ---
    if st.session_state['logged_in']:
        user_id = st.session_state['user']['id']
        df_transactions, accounts, categories = get_user_data(user_id)
        
        # --- Metrics ---
        # --- Metrics ---
        total_balance = sum(acc['balance'] for acc in accounts)
        
        # Calculate Total Expenses
        # Filter for expenses (assuming negative amounts or checking category type if available in DF)
        # Since we don't have category type in DF directly, we can infer or join. 
        # Simpler: Check if amount is negative? No, amount is positive in DB, logic handles sign.
        # Let's join category type or just check against known expense categories.
        # Better: Fetch category type in get_user_data or just use the list of categories we have.
        
        cat_type_map = {c['name']: c['type'] for c in categories}
        
        # Add type to DF
        if not df_transactions.empty:
            df_transactions['type'] = df_transactions['category'].map(cat_type_map)
            total_expenses = df_transactions[df_transactions['type'] == 'Expense']['amount'].sum()
        else:
            total_expenses = 0.0

        col_m1, col_m2 = st.columns(2)
        col_m1.metric("Total Balance", f"AED {total_balance:,.2f}")
        col_m2.metric("Total Expenses", f"AED {total_expenses:,.2f}")
        
        # --- Add Transaction Form ---
        with st.expander("Add New Transaction", expanded=True):
            with st.form("transaction_form"):
                col1, col2 = st.columns(2)
                with col1:
                    t_date = st.date_input("Date", datetime.now())
                    t_amount = st.number_input("Amount (AED)", min_value=0.01, step=0.01)
                    t_desc = st.text_input("Description")
                with col2:
                    # Filter categories by type
                    cat_names = [c['name'] for c in categories]
                    t_category = st.selectbox("Category", cat_names)
                    
                    # Get type of selected category
                    selected_cat_type = next((c['type'] for c in categories if c['name'] == t_category), 'Expense')
                    
                    # Dynamic Feedback
                    if selected_cat_type == 'Income':
                        st.info(f"Type: **{selected_cat_type}** (Will **ADD** to balance)")
                    else:
                        st.warning(f"Type: **{selected_cat_type}** (Will **DEDUCT** from balance)")
                    
                    acc_map = {a['name']: a['id'] for a in accounts}
                    t_account = st.selectbox("Account", list(acc_map.keys()))
                
                submitted = st.form_submit_button("Add Transaction")
                if submitted:
                    if add_transaction(user_id, t_date, t_amount, t_category, acc_map[t_account], t_desc, selected_cat_type):
                        st.success("Transaction added!")
                        st.rerun()

        # --- Dashboard ---
        col_chart, col_table = st.columns([1, 2])
        
        with col_chart:
            st.subheader("Expenses by Category")
            if not df_transactions.empty:
                # Filter for expenses
                df_expenses = df_transactions[df_transactions['type'] == 'Expense']
                
                if not df_expenses.empty:
                    # Pie Chart
                    fig_pie = px.pie(df_expenses, names='category', values='amount', title="Expense Distribution")
                    st.plotly_chart(fig_pie, use_container_width=True)
                    
                    # Bar Chart
                    fig_bar = px.bar(df_expenses, x='category', y='amount', color='category', title="Expenses by Category")
                    st.plotly_chart(fig_bar, use_container_width=True)
                    
                    # Line Chart (Spending over time)
                    # Group by date and type
                    df_daily = df_transactions.groupby(['date', 'type'])['amount'].sum().reset_index()
                    fig_line = px.line(df_daily, x='date', y='amount', color='type', title="Income & Expenses Over Time", markers=True)
                    st.plotly_chart(fig_line, use_container_width=True)
                else:
                    st.info("No expenses recorded yet.")
            else:
                st.info("No transactions yet.")
        
        with col_table:
            st.subheader("Recent Transactions")
            if not df_transactions.empty:
                st.dataframe(df_transactions[['date', 'category', 'description', 'amount']], use_container_width=True)
            else:
                st.info("No transactions found.")

    else:
        st.title("Personal Finance App")
        st.write("Please login or register to manage your finances.")
        st.info("Use the sidebar to authenticate.")

if __name__ == "__main__":
    main()
