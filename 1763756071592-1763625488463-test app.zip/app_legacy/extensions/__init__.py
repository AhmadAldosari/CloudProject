"""Flask extension instances."""
from .database import db

__all__ = ["db"]
